public interface AreaCalculavel {
	
	double calculaArea();

}
