import java.io.PrintStream;

public class TestaImpressao {
	public static void main(String[] args) {
		
		System.out.println("Mensagem 1");
		
		PrintStream saida = System.out;
		saida.println("Mensagem 2");
		
	}
}
