package br.com.banco.conta;
public interface Tributavel { // Esta é a interface
	
	double calculaTributos();

}
