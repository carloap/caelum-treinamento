package br.com.banco.conta;
public class SeguroDeVida implements Tributavel {

	@Override
	public double calculaTributos() {
		return 42;
	}
	

}
