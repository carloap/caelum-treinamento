
public class Executa2 implements Runnable {
	public void run() {
		for (int i = 0; i < 10000; i++) {
			System.out.println("Programa 1 valor: "+ i);
		}
	}
}
